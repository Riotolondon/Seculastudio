import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, Github, Filter } from 'lucide-react';
import GlassCard from '../components/GlassCard';

const Portfolio = () => {
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [activeFilter, setActiveFilter] = useState('all');

  const filterCategories = [
    { id: 'all', name: 'All Projects' },
    { id: 'web', name: 'Web Design' },
    { id: 'mobile', name: 'Mobile Apps' },
    { id: 'branding', name: 'Branding' },
    { id: 'ecommerce', name: 'E-commerce' }
  ];

  const projects = [
    {
      id: 1,
      title: 'TechFlow Dashboard',
      category: 'web',
      description: 'A modern analytics dashboard for SaaS companies',
      longDescription: 'TechFlow is a comprehensive analytics platform designed for SaaS companies to track user engagement, revenue metrics, and performance indicators. The dashboard features real-time data visualization, customizable widgets, and advanced filtering capabilities.',
      image: 'https://images.pexels.com/photos/160107/pexels-photo-160107.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React', 'TypeScript', 'D3.js', 'Node.js', 'PostgreSQL'],
      features: [
        'Real-time data visualization',
        'Customizable dashboard widgets',
        'Advanced filtering and search',
        'Export functionality',
        'Role-based access control'
      ],
      client: 'TechFlow Inc.',
      timeline: '12 weeks',
      team: 'UI/UX Designer, 2 Frontend Developers, Backend Developer',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      id: 2,
      title: 'Mindful Meditation App',
      category: 'mobile',
      description: 'Cross-platform meditation and wellness mobile application',
      longDescription: 'A comprehensive meditation app that helps users develop mindfulness practices through guided sessions, progress tracking, and personalized recommendations. Features include offline mode, sleep stories, and community challenges.',
      image: 'https://images.pexels.com/photos/3060132/pexels-photo-3060132.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['React Native', 'Redux', 'Firebase', 'Node.js', 'MongoDB'],
      features: [
        'Guided meditation sessions',
        'Progress tracking',
        'Offline mode support',
        'Sleep stories and sounds',
        'Community features'
      ],
      client: 'Wellness Co.',
      timeline: '16 weeks',
      team: 'Mobile Developer, UI/UX Designer, Backend Developer',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      id: 3,
      title: 'Stellar Brand Identity',
      category: 'branding',
      description: 'Complete brand identity for a fintech startup',
      longDescription: 'Stellar is a fintech startup focused on democratizing investment opportunities. We created a comprehensive brand identity that reflects trust, innovation, and accessibility through clean typography, strategic color choices, and modern iconography.',
      image: 'https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Adobe Creative Suite', 'Figma', 'Principle', 'After Effects'],
      features: [
        'Logo design and variations',
        'Brand guidelines',
        'Marketing materials',
        'Website design system',
        'Social media templates'
      ],
      client: 'Stellar Financial',
      timeline: '8 weeks',
      team: 'Brand Designer, Art Director, Motion Designer',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      id: 4,
      title: 'EcoMarket Platform',
      category: 'ecommerce',
      description: 'Sustainable marketplace for eco-friendly products',
      longDescription: 'EcoMarket is an e-commerce platform dedicated to sustainable and eco-friendly products. The platform features vendor management, carbon footprint tracking, subscription boxes, and a rewards program for environmentally conscious consumers.',
      image: 'https://images.pexels.com/photos/3735747/pexels-photo-3735747.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Next.js', 'Stripe', 'Prisma', 'PostgreSQL', 'Vercel'],
      features: [
        'Multi-vendor marketplace',
        'Carbon footprint tracking',
        'Subscription management',
        'Rewards program',
        'Advanced search and filtering'
      ],
      client: 'EcoMarket Ltd.',
      timeline: '20 weeks',
      team: '2 Frontend Developers, Backend Developer, DevOps Engineer',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      id: 5,
      title: 'ArtSpace Gallery',
      category: 'web',
      description: 'Digital art gallery with virtual exhibition spaces',
      longDescription: 'ArtSpace is a revolutionary digital art gallery that combines traditional art curation with cutting-edge web technologies. Features include 3D virtual exhibitions, artist portfolios, and an integrated marketplace for art collectors.',
      image: 'https://images.pexels.com/photos/1269968/pexels-photo-1269968.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Three.js', 'React', 'WebGL', 'Node.js', 'MongoDB'],
      features: [
        '3D virtual exhibitions',
        'Artist portfolio management',
        'Integrated marketplace',
        'VR compatibility',
        'Social sharing features'
      ],
      client: 'ArtSpace Foundation',
      timeline: '14 weeks',
      team: '3D Developer, Frontend Developer, UI/UX Designer',
      liveUrl: '#',
      githubUrl: '#'
    },
    {
      id: 6,
      title: 'FitTrack Mobile',
      category: 'mobile',
      description: 'Comprehensive fitness tracking and workout planning app',
      longDescription: 'FitTrack is a comprehensive fitness application that combines workout planning, progress tracking, and social features. Users can create custom workouts, track their progress, and connect with fitness communities.',
      image: 'https://images.pexels.com/photos/4164843/pexels-photo-4164843.jpeg?auto=compress&cs=tinysrgb&w=800',
      technologies: ['Flutter', 'Firebase', 'HealthKit', 'Google Fit'],
      features: [
        'Custom workout builder',
        'Progress tracking',
        'Social features',
        'Nutrition logging',
        'Wearable device integration'
      ],
      client: 'FitTrack Inc.',
      timeline: '18 weeks',
      team: 'Mobile Developer, Backend Developer, UI/UX Designer',
      liveUrl: '#',
      githubUrl: '#'
    }
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeFilter);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-24 pb-20"
    >
      {/* Hero Section */}
      <section className="px-4 sm:px-6 lg:px-8 mb-20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#2596be] to-blue-400">Portfolio</span>
            </h1>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Explore our latest projects and see how we've helped businesses transform their digital presence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="px-4 sm:px-6 lg:px-8 mb-12">
        <div className="max-w-7xl mx-auto">
          <GlassCard className="p-2">
            <div className="flex flex-wrap justify-center gap-2">
              {filterCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setActiveFilter(category.id)}
                  className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 flex items-center space-x-2 ${
                    activeFilter === category.id
                      ? 'bg-[#2596be] text-white shadow-lg'
                      : 'text-white/70 hover:text-white hover:bg-white/10'
                  }`}
                >
                  <Filter className="h-4 w-4" />
                  <span>{category.name}</span>
                </button>
              ))}
            </div>
          </GlassCard>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                onClick={() => setSelectedProject(project)}
                className="cursor-pointer"
              >
                <GlassCard className="group overflow-hidden">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xl font-semibold text-white">{project.title}</h3>
                      <span className="px-3 py-1 bg-[#2596be]/20 text-[#2596be] text-xs font-medium rounded-full">
                        {filterCategories.find(cat => cat.id === project.category)?.name}
                      </span>
                    </div>
                    <p className="text-white/70 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.slice(0, 3).map((tech) => (
                        <span
                          key={tech}
                          className="px-2 py-1 bg-white/10 text-white/60 text-xs rounded-md"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > 3 && (
                        <span className="px-2 py-1 bg-white/10 text-white/60 text-xs rounded-md">
                          +{project.technologies.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedProject(null)}
          >
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm"></div>
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <GlassCard className="p-0 overflow-hidden">
                <button
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 z-10 p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-colors duration-300"
                >
                  <X className="h-5 w-5" />
                </button>
                
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={selectedProject.image}
                    alt={selectedProject.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                </div>
                
                <div className="p-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-3xl font-bold text-white">{selectedProject.title}</h2>
                    <span className="px-4 py-2 bg-[#2596be]/20 text-[#2596be] font-medium rounded-full">
                      {filterCategories.find(cat => cat.id === selectedProject.category)?.name}
                    </span>
                  </div>
                  
                  <p className="text-white/80 text-lg mb-8">{selectedProject.longDescription}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-4">Key Features</h3>
                      <ul className="space-y-2">
                        {selectedProject.features.map((feature: string) => (
                          <li key={feature} className="flex items-center space-x-2 text-white/70">
                            <div className="w-2 h-2 bg-[#2596be] rounded-full"></div>
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-4">Project Details</h3>
                      <div className="space-y-3 text-white/70">
                        <div>
                          <span className="font-medium text-white">Client:</span> {selectedProject.client}
                        </div>
                        <div>
                          <span className="font-medium text-white">Timeline:</span> {selectedProject.timeline}
                        </div>
                        <div>
                          <span className="font-medium text-white">Team:</span> {selectedProject.team}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mb-8">
                    <h3 className="text-xl font-semibold text-white mb-4">Technologies Used</h3>
                    <div className="flex flex-wrap gap-3">
                      {selectedProject.technologies.map((tech: string) => (
                        <span
                          key={tech}
                          className="px-4 py-2 bg-white/10 text-white rounded-lg font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex space-x-4">
                    <a
                      href={selectedProject.liveUrl}
                      className="flex items-center space-x-2 px-6 py-3 bg-[#2596be] hover:bg-[#2596be]/80 text-white font-semibold rounded-lg transition-colors duration-300"
                    >
                      <ExternalLink className="h-5 w-5" />
                      <span>View Live</span>
                    </a>
                    <a
                      href={selectedProject.githubUrl}
                      className="flex items-center space-x-2 px-6 py-3 bg-white/10 border border-white/20 text-white font-semibold rounded-lg hover:bg-white/20 transition-colors duration-300"
                    >
                      <Github className="h-5 w-5" />
                      <span>View Code</span>
                    </a>
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <GlassCard className="p-8 md:p-12">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-xl text-white/70 mb-8 max-w-2xl mx-auto">
              Let's create something amazing together. Contact us to discuss your project and see how we can bring your vision to life.
            </p>
            <button className="px-8 py-4 bg-[#2596be] hover:bg-[#2596be]/80 text-white font-semibold rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-[#2596be]/25">
              Start Your Project
            </button>
          </GlassCard>
        </div>
      </section>
    </motion.div>
  );
};

export default Portfolio;